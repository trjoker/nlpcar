import pandas as pd
import jieba

# 将数据转化为向量形式
from cars.CleanData import CleanData


class WordVec:
    trainData = 'datas/AutoMaster_TrainSet.csv'
    testData = 'datas/AutoMaster_TestSet.csv'
    stopWords = 'datas/stopwords.txt'
    vocabToInt = 'datas/VocabToInt.txt'

    def cut(self, string):
        return jieba.cut(string)

    def get_stopwords_list(self, path):
        stopwords = [line.strip() for line in open(path, encoding='UTF-8').readlines()]
        return stopwords

    # 去除通用词
    def remove_stop_words(self, text):
        return [t for t in text if
                t.strip() and t not in self.get_stopwords_list(WordVec.stopWords)]

    # 去除空格
    def remove_space(self, text):
        return [t for t in text if t.strip()]

    def get_vocab(self, texts):
        vocab_set = set(texts)
        vocab_to_int = {word: index for index, word in enumerate(vocab_set)}
        with open(WordVec.vocabToInt, 'w+', encoding='UTF-8') as f:
            for k, v in vocab_to_int.items():
                f.write(str(k) + ' ' + str(v) + '\n')
        return vocab_to_int

    # 获取数据
    def get_vocab_data(self, path):
        dataFrame = pd.read_csv(WordVec.trainData, encoding="UTF-8")
        # 获取所需列
        dataFrame = dataFrame.iloc[:, 1:6]

        dataFrame2 = pd.read_csv(WordVec.testData, encoding="UTF-8")
        # 获取所需列
        dataFrame2 = dataFrame.iloc[:, 1:5]
        # 将所有列拼接成一个list
        text_list = []
        for index, row in dataFrame.iteritems():
            text_list.extend(dataFrame[index].tolist())
        for index, row in dataFrame2.iteritems():
            text_list.extend(dataFrame2[index].tolist())
        # 清洗数据
        print('清洗数据')
        text_list = [CleanData.cleanData(str(a)) for a in text_list]

        # 拼接所有字符串
        print('拼接所有字符串')
        text = ''
        for a in text_list:
            text += a
            text += ' '

        # 切词
        print('切词')
        cut_text = self.cut(text)

        # 去除空格
        print('去除空格')
        valid_text = self.remove_space(cut_text)

        # 生成词表文件
        print('生成词表文件')
        self.get_vocab(valid_text)


if __name__ == '__main__':
    # WordVec.getAllText(WordVec.trianData)
    # string = '我这边2017年9月23号买了一辆斯科达的科迪亚克7座豪华USV，2028年1月14号首保发现漏油4S店说是齿轮防锈油，用纸擦了一'
    # string = CleanData.cleanData(string)
    # cut_list = WordVec.cut(string)
    # for item in cut_list:
    #     print(item)
    # wordVec = WordVec()
    # string = '技师:[语音]的我这边2017年9月23号买了一辆斯科达的科迪亚克7座豪华USV，2028年1月14号首保发现漏油4S店说是齿轮防锈油，用纸擦了一下，4s店说是齿轮'
    # string = CleanData.cleanData(string)
    # print(string)
    # cut_text = wordVec.cut(string)
    # valid_text = wordVec.remove_stop_words(cut_text)
    # print(wordVec.get_vocab(valid_text))
    wordVec = WordVec()
    wordVec.get_vocab_data(WordVec.trainData)
